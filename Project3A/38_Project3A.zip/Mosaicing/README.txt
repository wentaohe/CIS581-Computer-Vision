To execute this project:

1. go to Mosaicing.m.

2. change the first few lines in Section 1 to the images you want.

3. click run to get your resulting image.

To see intermediate plots for corner detection and anms:

1. comment out section 6

2. uncomment section 2 and 5

3. click run.

To see intermediate plots for RANSAC:

1. comment out section 6

2. uncomment section 2 3 and 4

3. click run.