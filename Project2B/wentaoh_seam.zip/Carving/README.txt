Steps to execute the code:
1. open Carving.m
2. change the second line to the desired image to be carved
3. modify the third line.
4. the last two parameters of the carv functions represent the numbers of rows and columns to remove.
5. hit run and wait for the code to execute.
6. for a 140KB image, it takes about 242.4 seconds to run. Please be patient.