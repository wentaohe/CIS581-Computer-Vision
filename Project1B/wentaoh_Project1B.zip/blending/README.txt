How to execute:

Open test.m
Specify img and targetImg (line 1 and line 2)
Adjust offsetX and offsetY
Click run

THE CODE MAY RUN FOR A WHILE.
PLEASE BE PATIENT.