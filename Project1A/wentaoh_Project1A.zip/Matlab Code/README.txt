To test this code, please open Test_script.m, and change line 9 to load the file you want to test. It will generate seven figures to help you verify the correctness of the code.
Figure 1: Mag
Figure 2: Magx
Figure 3: Magy
Figure 4: orientation of derivatives
Figure 5: nonMaxSup
Figure 6: EdgeLink
Figure 7: Final Comparison between the original image and the output

To test pictures in bulk, please use CannyEdgeDetector.m, modify either the first or the second line to load the folder of pictures that you want to test, and remember to comment out the other one. Also remember to comment out line 21, 27, 32 to avoid too many figures popping out. All your results will be saved in the current folder.